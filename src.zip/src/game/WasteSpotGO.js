// @ts-check

import SpotGO from "./SpotGO.js";

export default class WasteSpotGO extends SpotGO {

    
}